#########ЭТОТ ФАЙЛ ПРЯВЫЗЫВАЕТ ФУНКЦИИ КНОПКА ЛЕВОГО МЕНЮ А ТАКЖЕ ТАЙТЛ БАРУ
import sys


#Импортирую все Qt модули
from qt_core import *


from gui.windows.main_window.ui_main_window import UI_MainWindow
from gui.pages.ui_pages import Ui_application_pages


GLOBAL_STATE = 0


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("WhyCode")
        self.setWindowFlag(Qt.FramelessWindowHint)

        #####СОЗДАНИЕ ОКНА
        self.ui = UI_MainWindow()
        self.ui.setup_ui(self)
        self.ui_pages = Ui_application_pages()
        self.pages = QStackedWidget()
        self.ui_pages.setup_Ui(self.pages)
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(20)
        self.shadow.setXOffset(0)
        self.shadow.setYOffset(0)
        self.shadow.setColor(QColor(0, 0, 0, 100))
        self.grip = QSizeGrip(self.ui.central_frame)

        #ПРИСВАИВАНИЕ ФУНКЦИЙ КНОПКАМ
        self.ui.toggle_button.clicked.connect(self.toggle_button)
        self.ui.btn_1.clicked.connect(self.show_page_1)
        self.ui.btn_2.clicked.connect(self.show_page_2)
        self.ui.settings_btn.clicked.connect(self.show_page_3)

        #ВОЗМОЖНОСТЬ ПЕРЕТЯГИВАТЬ ОКНО ЗА ТАЙТЛ БАР
        def moveWindow(event):
            if self.returnStatus() == 1:
                self.maximize_restore()
            if event.buttons() == Qt.LeftButton:
                self.move(self.pos() + event.globalPos() - self.dragPos)
                self.dragPos = event.globalPos()
                event.accept()

        self.ui.title_lable.mouseMoveEvent = moveWindow
        self.ui.btn_form.clicked.connect(lambda: self.maximize_restore())
        self.ui.btn_min.clicked.connect(lambda: self.showMinimized())
        self.ui.btn_close.clicked.connect(lambda: self.close())
        self.ui.btn_donate.clicked.connect(lambda: webbrowser.open('https://www.donationalerts.com/r/whycompany'))


############################## я эту штуку два раза блин удалял #################
        self.show()
############################## она  показывает приложение ########################

    #СБРОС ВЫБОРА КНОПКИ
    def reset_selection(self):
        for btn in self.ui.left_menu.findChildren(QPushButton):
            try:
                btn.set_active(False)
            except:
                pass

    #ОТКРЫТИЕ ПЕРВОЙ СТРАНИЦЫ
    def show_page_1(self):
        self.reset_selection()
        self.ui.pages.setCurrentWidget(self.ui.ui_pages.page_1)
        self.ui.btn_1.set_active(True)

    #ОТКРЫТИЕ ВТРОЙ СТРАНИЦЫ
    def show_page_2(self):
        self.reset_selection()
        self.ui.pages.setCurrentWidget(self.ui.ui_pages.page_2)
        self.ui.btn_2.set_active(True)

    #КТО ЭТО ЧИТАЕТ
    def show_page_3(self):
        self.reset_selection()
        self.ui.pages.setCurrentWidget(self.ui.ui_pages.page_3)
        self.ui.settings_btn.set_active(True)

    #РАСШИРЕНИЕ ЛЕВОГО МЕНЮ
    def toggle_button(self):
        menu_width = self.ui.left_menu.width()
        width = 50
        if menu_width == 50:
            width = 240

        #АНИМАЦИЯ
        self.animation = QPropertyAnimation(self.ui.left_menu, b"minimumWidth")
        self.animation.setStartValue(menu_width)
        self.animation.setEndValue(width)
        self.animation.setDuration(500)
        self.animation.setEasingCurve(QEasingCurve.InOutCirc)
        self.animation.start()

    #ФУНКЦИЯ КНОПКИ ИЗМЕНЕНИЯ РАЗМЕРОВ ОКНА
    def maximize_restore(self):
        global GLOBAL_STATE
        status = GLOBAL_STATE

        if status == 0:
            self.showMaximized()

            GLOBAL_STATE = 1
            self.ui.btn_form.setToolTip('Restore')
            self.ui.btn_form.setIcon(QIcon(u'gui/images/icons/icon_bigsize.png'))
        else:
            GLOBAL_STATE = 0
            self.showNormal()
            self.resize(self.width()+1, self.height()+1)
            self.ui.btn_form.setToolTip('Maximize')
            self.ui.btn_form.setIcon(QIcon(u'gui/images/icons/icon_form_start.png'))


    def mousePressEvent(self, event):
        self.dragPos = event.globalPos()

    def returnStatus(self):
        return GLOBAL_STATE


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    window = MainWindow()
    sys.exit(app.exec())