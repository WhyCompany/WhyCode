##############ЭТОТ ФАЙЛ СОЗДАЁТ СТРАНИЦЫ, А ТАК ЖЕ ДЕЖАЩИЕ В НИХ ВИДЖЕТЫ###############
#ВСЕ ПЕРЕМННЫЕ В ФАЙЛЕ Я СТАРАЛСЯ НАЗЫВАТЬ С МАКСИМАЛЬНЫМ СООТВЕТСВИЕМ СОВЕГО ПРЕДНАЗНАЧЕНИЯ#
from qt_core import *
from gui.widgets.py_toggle import PyToggle
from ..widgets.PyPlainTextEdit import PlainTextEdit
from ..widgets.highlight import Highligher

id = QFontDatabase.addApplicationFont(':ZenKurenaidoRegular.ttf')#Я НЕ УВЕРЕН, ЧТО ЭТО НУЖНО, НГ БОЮСЬ УДОЛЯТЬ
#СВЕТЛАЯ ТЕМА
light_theme = """    
    QWidget{
        background-color: #dedede;
    }
    QFrame{
        background-color: #dedede;
        color: #1f1f1f;
        border-radius: 10px;
    }
    QPlainTextEdit{
    background-color: #dedede;
    font: 700 16pt \"Zen Kurenaido\";
    padding: 8px;
    color: #1f1f1f;
    border-radius: 10px;
    }
    QPushButton{
    background-color: #dedede;
    font: 8pt;
    padding: 8px;
    color: #1f1f1f;
    border-radius: 6px;
    }
    QPushButton:pressed{
    background-color: #ababab;
    font: 8pt;
    padding: 8px;
    color: #1f1f1f;
    border-radius: 6px;
    }
    /* VERTICAL SCROLLBAR */
    QScrollBar:vertical {
        border: none;
        background: #dedede;
        width: 10px;
        margin: 15px 0 15px 0;
        border-radius: 0px;
    }

    /*  HANDLE BAR VERTICAL */
    QScrollBar::handle:vertical {
        background-color: #aeb3bc;
        min-height: 30px;
        border-radius: 4px;
    }
    QScrollBar::handle:vertical:hover{
        background-color: #aeb3bc;
    }
    QScrollBar::handle:vertical:pressed {
        background-color: #aeb3bc;
    }

    /* BTN TOP - SCROLLBAR */
    QScrollBar::sub-line:vertical {
        border: none;
        background-color: #dedede;
        height: 15px;
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
        subcontrol-position: top;
        subcontrol-origin: margin;
    }
    QScrollBar::sub-line:vertical:hover { 
        background-color: #dedede;
    }
    QScrollBar::sub-line:vertical:pressed {
        background-color: #dedede;
    }

    /* BTN BOTTOM - SCROLLBAR */
    QScrollBar::add-line:vertical {
        border: none;
        background-color: #dedede;
        height: 15px;
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        subcontrol-position: bottom;
        subcontrol-origin: margin;
    }
    QScrollBar::add-line:vertical:hover { 
        background-color: #dedede;
    }
    QScrollBar::add-line:vertical:pressed { 
        background-color: #dedede;
    }

    /* RESET ARROW */
    QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {
        background: none;
    }
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
        background: none;
    }

    /* HORIZONTAL SCROLLBAR - HOMEWORK */
    QScrollBar:horizontal {
    }
    QScrollBar::handle:horizontal {
    }
    QScrollBar::add-line:horizontal {
    }
    QScrollBar::sub-line:horizontal {
    }
    QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal
    {
    }
    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal
    {
    }
    """
#ТЁМНАЯ ТЕМА
dark_theme = """
    QWidget{
        background-color: #282c34;
    }
    QFrame{
        background-color: #282c34;
        color: #ffffff;
        border-radius: 10px;
    }
    QPlainTextEdit{
    background-color: #282c34;
    font: 700 16pt \"Zen Kurenaido\";
    padding: 8px;
    color: #aeb4b4;
    border-radius: 6px;
    }
    QPushButton{
    background-color: #282c34;
    font: 8pt;
    padding: 8px;
    color: #aeb4b4;
    border-radius: 6px;
    }
    QPushButton:pressed{
    background-color: #262931;
    font: 8pt;
    padding: 8px;
    color: #aeb4b4;
    border-radius: 6px;
    }
    QScrollBar:vertical {              
        border: none;
        background: white;
        width: 5px;               
        margin: 0px 0px 0px 0px;
        min-height: 0px;  
    }
    QScrollBar::handle:vertical {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop: 0 rgb(32, 47, 130), stop: 0.5 rgb(32, 47, 130), stop:1 rgb(32, 47, 130));
        min-height: 0px;
    }
    QScrollBar::add-line:vertical {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop: 0 rgb(32, 47, 130), stop: 0.5 rgb(32, 47, 130),  stop:1 rgb(32, 47, 130));
        height: 0px;
        subcontrol-position: bottom;
        subcontrol-origin: margin;
    }
    QScrollBar::sub-line:vertical {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop: 0  rgb(32, 47, 130), stop: 0.5 rgb(32, 47, 130),  stop:1 rgb(32, 47, 130));
        height: 0 px;
        subcontrol-position: top;
        subcontrol-origin: margin;
    }
    /* VERTICAL SCROLLBAR */
    QScrollBar:vertical {
        border: none;
        background: #282c34;
        width: 10px;
        margin: 15px 0 15px 0;
        border-radius: 0px;
    }

    /*  HANDLE BAR VERTICAL */
    QScrollBar::handle:vertical {
        background-color: #4a4e54;
        min-height: 30px;
        border-radius: 4px;
    }
    QScrollBar::handle:vertical:hover{
        background-color: #4a4e54;
    }
    QScrollBar::handle:vertical:pressed {
        background-color: #4a4e54;
    }

    /* BTN TOP - SCROLLBAR */
    QScrollBar::sub-line:vertical {
        border: none;
        background-color: #282c34;
        height: 15px;
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
        subcontrol-position: top;
        subcontrol-origin: margin;
    }
    QScrollBar::sub-line:vertical:hover { 
        background-color: #282c34;
    }
    QScrollBar::sub-line:vertical:pressed {
        background-color: #282c34;
    }

    /* BTN BOTTOM - SCROLLBAR */
    QScrollBar::add-line:vertical {
        border: none;
        background-color: #282c34;
        height: 15px;
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        subcontrol-position: bottom;
        subcontrol-origin: margin;
    }
    QScrollBar::add-line:vertical:hover { 
        background-color: #282c34;
    }
    QScrollBar::add-line:vertical:pressed { 
        background-color: #282c34;
    }

    /* RESET ARROW */
    QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {
        background: none;
    }
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
        background: none;
    }

    /* HORIZONTAL SCROLLBAR - HOMEWORK */
    QScrollBar:horizontal {
    }
    QScrollBar::handle:horizontal {
    }
    QScrollBar::add-line:horizontal {
    }
    QScrollBar::sub-line:horizontal {
    }
    QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal
    {
    }
    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal
    {
    }
    """

class Ui_application_pages(object):

    #ТЕМА ВНУТРИ КЛАССА НУЖНА, ЧТОБЫ Я МОГ УМПОРТИРОВАТЬ ЕЁ НА ОБЪЕКТЫ В ДРУГИХ КЛАССАХ ДРУГИХ ФАЙЛОВ
    dark_theme = """
    QWidget{
        background-color: #282c34;
    }
    QFrame{
        background-color: #282c34;
        color: #ffffff;
        border-radius: 10px;
    }
    QPlainTextEdit{
    background-color: #282c34;
    font: 700 16pt \"Zen Kurenaido\";
    padding: 8px;
    color: #aeb4b4;
    border-radius: 6px;
    }
    QPushButton{
    background-color: #282c34;
    font: 8pt;
    padding: 8px;
    color: #aeb4b4;
    border-radius: 6px;
    }
    QPushButton:pressed{
    background-color: #262931;
    font: 8pt;
    padding: 8px;
    color: #aeb4b4;
    border-radius: 6px;
    }
    #btn_close:hover{
    background-color: #b31a16;
    font: 8pt;
    padding: 8px;
    color: #aeb4b4;
    border-radius: 6px;
    }
    QScrollBar:vertical {              
        border: none;
        background: white;
        width: 5px;               
        margin: 0px 0px 0px 0px;
        min-height: 0px;  
    }
    QScrollBar::handle:vertical {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop: 0 rgb(32, 47, 130), stop: 0.5 rgb(32, 47, 130), stop:1 rgb(32, 47, 130));
        min-height: 0px;
    }
    QScrollBar::add-line:vertical {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop: 0 rgb(32, 47, 130), stop: 0.5 rgb(32, 47, 130),  stop:1 rgb(32, 47, 130));
        height: 0px;
        subcontrol-position: bottom;
        subcontrol-origin: margin;
    }
    QScrollBar::sub-line:vertical {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop: 0  rgb(32, 47, 130), stop: 0.5 rgb(32, 47, 130),  stop:1 rgb(32, 47, 130));
        height: 0 px;
        subcontrol-position: top;
        subcontrol-origin: margin;
    }
    /* VERTICAL SCROLLBAR */
    QScrollBar:vertical {
        border: none;
        background: #282c34;
        width: 10px;
        margin: 15px 0 15px 0;
        border-radius: 0px;
    }

    /*  HANDLE BAR VERTICAL */
    QScrollBar::handle:vertical {
        background-color: #4a4e54;
        min-height: 30px;
        border-radius: 4px;
    }
    QScrollBar::handle:vertical:hover{
        background-color: #4a4e54;
    }
    QScrollBar::handle:vertical:pressed {
        background-color: #4a4e54;
    }

    /* BTN TOP - SCROLLBAR */
    QScrollBar::sub-line:vertical {
        border: none;
        background-color: #282c34;
        height: 15px;
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
        subcontrol-position: top;
        subcontrol-origin: margin;
    }
    QScrollBar::sub-line:vertical:hover { 
        background-color: #282c34;
    }
    QScrollBar::sub-line:vertical:pressed {
        background-color: #282c34;
    }

    /* BTN BOTTOM - SCROLLBAR */
    QScrollBar::add-line:vertical {
        border: none;
        background-color: #282c34;
        height: 15px;
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        subcontrol-position: bottom;
        subcontrol-origin: margin;
    }
    QScrollBar::add-line:vertical:hover { 
        background-color: #282c34;
    }
    QScrollBar::add-line:vertical:pressed { 
        background-color: #282c34;
    }

    /* RESET ARROW */
    QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {
        background: none;
    }
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
        background: none;
    }

    /* HORIZONTAL SCROLLBAR - HOMEWORK */
    QScrollBar:horizontal {
    }
    QScrollBar::handle:horizontal {
    }
    QScrollBar::add-line:horizontal {
    }
    QScrollBar::sub-line:horizontal {
    }
    QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal
    {
    }
    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal
    {
    }
    """

    def setup_Ui(self, application_pages):
        if not application_pages.objectName():
            application_pages.setObjectName(u"application_pages")
        application_pages.resize(1056, 657)
        #СТРАНИЦА 1
        self.page_1 = QWidget()
        self.page_1.setObjectName(u"page_1")
        self.page_1.setStyleSheet(dark_theme)
        self.page_1.setStyleSheet('background-color: #22252c')
        self.centrallayout = QGridLayout(self.page_1)
        self.centrallayout.setObjectName(u"centrallayout")

        #ВИДЖЕТ ИЗ ДРУГОГО ФАЙЛА ДЛЯ СОЗДАНИЯ КОНТЕКСТНЫХ ПОДСВЕТОК
        self.highlighter = Highligher()

        #ПОДСВЕТКА КЛАССОВ
        class_format = QTextCharFormat()
        class_format.setForeground(QColor('#d45abe'))
        pattern = r'^\s*class\s'
        self.highlighter.add_mapping(pattern, class_format)

        #ПОДСВЕТКА ПРИНТА
        print_format = QTextCharFormat()
        print_format.setForeground(QColor('#d09354'))
        pattern = r'print'
        self.highlighter.add_mapping(pattern, print_format)

        #ПОДСВЕТКА ФУНКЦИЙ
        function_format = QTextCharFormat()
        function_format.setForeground(QColor('#d09354'))
        pattern = r'^\s*def\s'
        self.highlighter.add_mapping(pattern, function_format)


        #ПОДСВЕТКА IF И ELSE
        operator_format = QTextCharFormat()
        operator_format.setForeground(QColor('#5591af'))
        pattern = r'^\s*if\s'
        self.highlighter.add_mapping(pattern, operator_format)
        pattern = r'^\s*else'
        self.highlighter.add_mapping(pattern, operator_format)

        #ПОДСВЕТКА ЦИКЛОВ
        cycle_format = QTextCharFormat()
        cycle_format.setForeground(QColor('#9e9400'))
        pattern = r'^\s*for\s'
        self.highlighter.add_mapping(pattern, cycle_format)
        pattern = r'^\s*while'
        self.highlighter.add_mapping(pattern, cycle_format)

        #ПОДСВЕТКА(ЗАТЕМНЕНИЕ) КОММЕНТАРИЕВ
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor('#787878'))#898b8b
        pattern = r'#.*$'
        self.highlighter.add_mapping(pattern, comment_format)

        from_import_format = QTextCharFormat()
        from_import_format.setForeground(QColor('#f69905'))
        pattern = r'import\s'
        self.highlighter.add_mapping(pattern, from_import_format)
        pattern = r'^\s*from\s'
        self.highlighter.add_mapping(pattern, from_import_format)

        #ПОЛЕ ДЛЯ ВВОДА
        self.textEdit = QPlainTextEdit()
        self.textEdit.setObjectName(u"lineEdit")
        self.textEdit.setStyleSheet(dark_theme)
        self.highlighter.setDocument(self.textEdit.document())

        #############БЛОК КНОПОК РАБОТЫ С ФАЙЛОМ################
        self.path = None #СТАНДАРТНОЕ ЗНАЧЕНИЕ ПУТИ К ФАЛУ(НУЖНО В ФУНКЦИЯХ)
        #КНОПКА СОХРАНЕНИЯ ФАЙЛА
        self.btn_saveAss = QPushButton('Save As')
        self.btn_saveAss.setStyleSheet(dark_theme)
        self.btn_saveAss.setFixedSize(100, 25)
        self.btn_saveAss.clicked.connect(self.saveAssFunct)

        #КНОПКА СОЗДАНИЯ НВОГО ФАЙЛА
        self.btn_new = QPushButton('New')
        self.btn_new.setStyleSheet(dark_theme)
        self.btn_new.setFixedSize(100, 25)
        self.btn_new.clicked.connect(self.new_run)

        #КНОПКА СОХРАНЕНИЯ ИЗМЕНЕНИЙ
        self.btn_save = QPushButton('Save')
        self.btn_save.setStyleSheet(dark_theme)
        self.btn_save.setFixedSize(100, 25)
        self.btn_save.clicked.connect(self.saving_run)\

        #КНОПКА ЗАПУСКА ПРОГРАММЫ(Я НЕ ЗНАЮ РАБОТАЕТ ОНА ТИПА ТАМ ИЛИ ТАМ ТИПА ЧТО ಠ_ಠ)
        self.btn_run = QPushButton('Run')
        self.btn_run.setStyleSheet(dark_theme)
        self.btn_run.setFixedSize(120, 25)
        self.btn_run.clicked.connect(self.run)
        self.btn_run.clicked.connect(self.sound_play()) #ПО ИДЕЕ ФУНКЦИЯ ПРИВЯЗЫВАЕТСЯ К НАЖАТИЮ КНОПКИ, НО ПОЧЕМУ ТО
        #АКТИВИРУЕТСЯ С ЗАПУСКОМ ПРОГРАММЫ И ПОТОМ НЕ РАБОТАЕТ

        #КНОПКА ОТКРЫТИЯ ФАЙЛА
        self.btn_open = QPushButton('Open')
        self.btn_open.setStyleSheet(dark_theme)
        self.btn_open.setFixedSize(120, 25)
        self.btn_open.clicked.connect(self.opening_run)

        #ФРЭЙМ КОТОРЫЙ НУЖЕН ТОЛЬКО ЧТОБЫ КНОПКИ НЕ РАСТЯГИВАЛИСЬ, ЗАНИМАЕТ ПУСТОЕ ПРОСТРАНСТВО МЕЖДУ КОНПКАМИ ЛЕВОЙ И ПРАВОЙ ЧАСТИ
        self.frame_useless = QFrame(self.page_1)

        #ДОБАВЛЕНИЕ КНОПОК ЭТОГО БЛОКА В КОНТЕЙНЕР ПЕРВОЙ СТРАНИЦЫ
        self.centrallayout.addWidget(self.btn_saveAss, 0, 1)
        self.centrallayout.addWidget(self.btn_save, 0, 2)
        self.centrallayout.addWidget(self.btn_new, 0, 3)
        self.centrallayout.addWidget(self.frame_useless, 0, 4)
        self.centrallayout.addWidget(self.btn_open, 0, 5)
        self.centrallayout.addWidget(self.btn_run, 0, 6)
        self.centrallayout.addWidget(self.textEdit, 1, 1, 2, 6)

        application_pages.addWidget(self.page_1)

        #ВТОРАЯ СТРАНИЦА
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.page_2.setStyleSheet(dark_theme)
        self.page_2.setStyleSheet('background-color: #22252c')
        self.page2_layout = QGridLayout(self.page_2)

        self.future = QLabel()
        self.future.setText('Тут мы хотели сделать удобный список различных сторонних библиотек \n'
        'для ваших проектов, с поиском по ключевым словам, небольшим описанием, а так же примером работы библеотеки.\n'
                           'Но к сожалению нам не хватило времнени, сил, желания и нормальных обучалок по PyQt')
        self.future.setStyleSheet('font: 700 16pt;')
        self.future.setStyleSheet(dark_theme)



        self.page2_layout.addWidget(self.future, 0, 2)

        application_pages.addWidget(self.page_2)

        #ТРЕТЬЯ СТРАНИЦА
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.page_3.setStyleSheet(dark_theme)
        self.page_3.setStyleSheet('background-color: #22252c')
        self.layout3 = QGridLayout(self.page_3)
        self.layout3.setObjectName(u"layout_3")

        #ВИДЖЕТ ПЕРЕКЛЮЧАТЕЛЯ СВЕТЛОЙ ТЕМЫ ТЕМЫ И ЕЁ НАДПИСЬ
        self.label = QLabel()
        self.label.setObjectName(u"label")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setText("Light theme")
        self.btn_bw = PyToggle()
        self.btn_bw.stateChanged.connect(self.state_changed)

        #2 БЕСПОЛЕЗНЫХ ПЕРЕКЛЮЧАТЕЛЯ И 2 БЕСПОЛЕЗНЫЕ НАДПИСИ КОТОРЫЕ ЧТОБЫ КРАСИВО
        self.btn_chng = PyToggle()
        self.label_chng = QLabel()
        self.label_chng.setObjectName(u"label_chng")
        self.label_chng.setAlignment(Qt.AlignCenter)
        self.label_chng.setText("parameter 1")
        self.btn_chng1 = PyToggle()
        self.label_chng1 = QLabel()
        self.label_chng1.setObjectName(u"label_chng1")
        self.label_chng1.setAlignment(Qt.AlignCenter)
        self.label_chng1.setText("parameter 2")

        #ФРЭЙМ ДЛЯ КОТЕЙНЕРА С ТОЛЬКО ЧТО ПЕРЕЧИСЛЕНЫМИ ВИДЖЕТАМИ
        self.frame_basic = QFrame(self.page_3)
        self.frame_basic.setObjectName(u"frame_basic")
        self.frame_basic.setMinimumSize(QSize(450, 330))
        self.frame_basic.setMaximumSize(QSize(450, 330))
        self.frame_basic.setStyleSheet(u"QFrame {\n"
                                    "	background-color: rgb(40,44,52);\n"
                                    "	color: rgb(255, 255, 255);\n"
                                    "	border-radius: 10px;\n"
                                    "}")

        #КОНТЕЙНЕР ДЛЯ ВИДЖЕТОВ ВЫШЕ
        self.basic_layout = QGridLayout(self.frame_basic)
        self.basic_layout.setObjectName(u"basic_layout")
        #ДОБАВЛЕНИЕ ВИДЖЕТОВ В СЕЙ КРУТОЙ КОТЕЙНЕР
        self.basic_layout.addWidget(self.btn_bw, 0, 0)
        self.basic_layout.addWidget(self.label, 0 ,1)
        self.basic_layout.addWidget(self.btn_chng, 1, 0)
        self.basic_layout.addWidget(self.label_chng, 1, 1)
        self.basic_layout.addWidget(self.btn_chng1, 2, 0)
        self.basic_layout.addWidget(self.label_chng1, 2, 1)

        ######3 ФРЭЙМА ПРОСТО ЧТОБЫ КРАСИВО ЗАПОЛНИТЬ ОСТАВШЕЕСЯ НА СТРАНИЦЕ МЕСТО
        self.frame2 = QFrame(self.page_3)
        self.frame2.setObjectName(u"frame2")
        self.frame2.setStyleSheet(self.dark_theme)

        self.frame3 = QFrame(self.page_3)
        self.frame3.setObjectName(u"frame3")
        self.frame3.setStyleSheet(self.dark_theme)

        self.frame4 = QFrame(self.page_3)
        self.frame4.setObjectName(u"frame4")
        self.frame4.setStyleSheet(self.dark_theme)
        #ДОБАВЛЕНИЯ ФРЭЙМА С ВИДЖЕТАМИ И 3 БЕСПОЛЕЗНЫХ ФРЭЙМОВ В КОНТЕЙНЕР ТРЕТЬЕЙ СТРАНИЦЫ
        self.layout3.addWidget(self.frame_basic, 0, 0)
        self.layout3.addWidget(self.frame2, 0, 1)
        self.layout3.addWidget(self.frame3, 1, 0)
        self.layout3.addWidget(self.frame4, 1, 1)


        application_pages.addWidget(self.page_3)

        #self.retranslateUi(application_pages)
        #QMetaObject.connectSlotsByName(application_pages)

    #################################ФУЕКЦИИ ДЛЯ ВИДЖЕТОВ ИЗ ЭТОГО ФАЙЛА#####################

    #ФУНКЦИЯ СМЕНЫ ТЕМЫ
    def state_changed(self):
        if self.btn_bw.isChecked():
            self.page_3.setStyleSheet(light_theme)
            self.page_3.setStyleSheet('background-color: #fafafa')
            self.frame_basic.setStyleSheet(light_theme)
            self.frame4.setStyleSheet(light_theme)
            self.frame3.setStyleSheet(light_theme)
            self.frame2.setStyleSheet(light_theme)

            self.page_2.setStyleSheet(light_theme)
            self.page_2.setStyleSheet('background-color: #fafafa')

            self.page_1.setStyleSheet(light_theme)
            self.page_1.setStyleSheet('background-color: #fafafa')
            self.textEdit.setStyleSheet(light_theme)
            self.btn_save.setStyleSheet(light_theme)
            self.btn_run.setStyleSheet(light_theme)
            self.btn_open.setStyleSheet(light_theme)
            self.btn_saveAss.setStyleSheet(light_theme)
            self.btn_new.setStyleSheet(light_theme)
        else:
            self.page_3.setStyleSheet(dark_theme)
            self.page_3.setStyleSheet('background-color: #22252c')
            self.frame4.setStyleSheet(dark_theme)
            self.frame3.setStyleSheet(dark_theme)
            self.frame2.setStyleSheet(dark_theme)

            self.page_2.setStyleSheet(dark_theme)
            self.page_2.setStyleSheet('background-color: #22252c')

            self.page_1.setStyleSheet(dark_theme)
            self.page_1.setStyleSheet('background-color: #22252c')
            self.frame_basic.setStyleSheet(dark_theme)
            self.textEdit.setStyleSheet(dark_theme)
            self.btn_save.setStyleSheet(dark_theme)
            self.btn_saveAss.setStyleSheet(dark_theme)
            self.btn_new.setStyleSheet(dark_theme)
            self.btn_run.setStyleSheet(dark_theme)
            self.btn_open.setStyleSheet(dark_theme)

    #СОЗДАНИЕ ДИАЛГОВОГО ОКНА ТИПА ПОЛУАЧЕТСЯ
    def dialog_critical(self, s):
        dlg = QMessageBox(self)
        dlg.setText(s)
        dlg.setIcon(QMessageBox.Critical)
        dlg.show()
    #ОТКРЫТИЕ ФАЙЛА
    def opening_run(self):
        path, _ = QFileDialog.getOpenFileName(None, "Open file", "", "Python files (*.py)")

        if path:
            try:
                with open(path, 'rU') as f:
                    text = f.read()

            except Exception as e:
                self.dialog_critical(str(e))

            else:
                self.path = path
                self.textEdit.setPlainText(text)

    #СОХРАНИЕНИЕ ИЗМЕНЕНИЯ
    def saving_run(self):
        if self.path is None:

            return self.saveAssFunct()

        self._save_to_path(self.path)

    #СОХРАНИЕ ФАЙЛА
    def saveAssFunct(self):
        path, filter = QFileDialog.getSaveFileName(None, "Save file", "", "Python files (*.py)")

        if not path:

            return

        self._save_to_path(path)

    #СЛОЖНАЯ К МОЕМУ ПОНИМАНИЮ ВЕЩЬ
    def _save_to_path(self, path):
        code = self.textEdit.toPlainText()
        try:
            with open(path, 'w') as f:
                f.write(self.code)

        except Exception as e:
            self.dialog_critical(str(e))

        else:
            self.path = path

    #СОЗДАНИЕ НОВГО ФАЙЛА(ОЧИЩЕНИЕ ПОЛЯ)
    def new_run(self):
        if self.path is None:
            return self.saveAssFunct()

        self.textEdit.clear()

    #ЗАПУСК ПРОГРАММЫ(В .ЕХЕ РАБОТАЕТ)
    def run(self):
        if self.path is None:
            return self.saveAssFunct()

        os.system(f'python {self.path}')

    #ТА САМАЯ КРИВОРУКАЯ ФУНКЦИЯ ОЗВУЧКИ КОНПКИ РАН
    def sound_play(self):
        self.sound = "gui/sounds/knock1.mp3"
        self.player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.player.setAudioOutput(self.audio_output)
        self.player.setSource(QUrl.fromLocalFile(self.sound))
        self.player.play()
