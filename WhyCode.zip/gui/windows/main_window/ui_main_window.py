#######ФАЙЛ ПРИНИМАЕТ СТРАНИЦЫ, СОЗДАЁТ БОКОВОЕ МЕНЮ, ТАЙТЛ БАР, И ВООБЩЕ НОРМАЛЬНО##############
###ВОЗМОЖНО ТУТ БУДЕТ ВСЁ НЕ ТАК ПОДРОБНО КАК В СТРАНИЦАХ, ПОТОМУ ЧТО Я УСТАЛ ПИСАТЬ КОММЕНТАРИИ
from qt_core import *


from gui.pages.ui_pages import Ui_application_pages
from gui.widgets.py_push_button import PyPushButton, LogoPushButton


class UI_MainWindow(object):
    def setup_ui(self, parent):
        if not parent.objectName():
            parent.setObjectName("MainWindow")
        parent.resize(1200, 720)
        parent.setMinimumSize(960, 580)

        #########ЦЕНТРАЛMYSQ ФРЭЙМ И ИМПОРТИРОВАНИЕ СТРАНИЦ
        self.ui_pages = Ui_application_pages()
        self.central_frame = QFrame()

        #ЦЕНТРАЛЬНЫЙ КНОТЭЙНЕР
        self.main_layout = QGridLayout(self.central_frame)
        self.main_layout.setContentsMargins(0,0,0,0)
        self.main_layout.setSpacing(0)

        ########################ВИДЖЕТЫ ТАЙТЛ БАРА################
        self.title_lable = QLabel("WhyCode")
        self.title_lable.setStyleSheet(self.ui_pages.dark_theme)
        self.title_lable.setAlignment(Qt.AlignLeft)

        self.btn_close = QPushButton()
        self.btn_close.setFixedSize(35, 35)
        self.btn_close.setStyleSheet(self.ui_pages.dark_theme)
        self.btn_close.setStyleSheet((u"QPushButton{\n"
                                    "	background-color: #282c34;\n"
                                    "	padding: 8px;\n"
                                    "	color: #aeb4b4;\n"
                                    "	border-radius: 6px;\n"
                                    "}"
                                    "QPushButton:pressed{\n"
                                    "	background-color: #282c34;\n"
                                    "	padding: 8px;\n"
                                    "	color: #aeb4b4;\n"
                                    "	border-radius: 6px;\n"
                                    "}"
                                       "QPushButton:hover{\n"
                                    "	background-color: #b31a16;\n"
                                    "	padding: 8px;\n"
                                    "	color: #aeb4b4;\n"
                                    "	border-radius: 6px;\n"
                                    "}"))
        self.btn_close.setIcon(QIcon(u'gui/images/icons/icon_close.png'))

        self.btn_min = QPushButton()
        self.btn_min.setFixedSize(35, 35)
        self.btn_min.setStyleSheet((u"QPushButton{\n"
                                      "	background-color: #282c34;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"
                                      "QPushButton:pressed{\n"
                                      "	background-color: #282c34;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"
                                      "QPushButton:hover{\n"
                                      "	background-color: #373a40;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"))
        self.btn_min.setIcon(QIcon(u'gui/images/icons/icon_min.png'))


        self.btn_form = QPushButton()
        self.btn_form.setFixedSize(35, 35)
        self.btn_form.setStyleSheet((u"QPushButton{\n"
                                      "	background-color: #282c34;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"
                                      "QPushButton:pressed{\n"
                                      "	background-color: #282c34;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"
                                      "QPushButton:hover{\n"
                                      "	background-color: #373a40;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"))
        self.btn_form.setIcon(QIcon(u'gui/images/icons/icon_form_start.png'))
        self.btn_form.setIconSize(QSize(16, 16))

        self.title_lable.setFixedHeight(35)
        self.title_lable.setAlignment(Qt.AlignCenter)

        self.btn_donate = QPushButton()
        self.btn_donate.setFixedSize(35, 35)
        self.btn_donate.setStyleSheet((u"QPushButton{\n"
                                      "	background-color: #282c34;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"
                                      "QPushButton:pressed{\n"
                                      "	background-color: #282c34;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"
                                      "QPushButton:hover{\n"
                                      "	background-color: #373a40;\n"
                                      "	padding: 8px;\n"
                                      "	color: #aeb4b4;\n"
                                      "	border-radius: 6px;\n"
                                      "}"))
        self.btn_donate.setIcon(QIcon(u'gui/images/icons/icon_donate.png'))


        #ЧЬО
        self.start = QPoint(0, 0)
        self.pressing = False

        ####БЛОК СОЗДАНИЯ ЛЕВОГО МЕНЮ
        self.left_menu = QFrame()
        self.left_menu.setStyleSheet("background-color: #323844")
        self.left_menu.setMaximumWidth(50)
        self.left_menu.setMinimumWidth(50)

        self.left_menu_layout = QVBoxLayout(self.left_menu)
        self.left_menu_layout.setContentsMargins(0,0,0,0)
        self.left_menu_layout.setSpacing(0)

        self.left_menu_top_frame = QFrame()
        self.left_menu_top_frame.setMinimumHeight(40)
        self.left_menu_top_frame.setObjectName("left_menu_top_frame")

        self.left_menu_top_layout = QVBoxLayout(self.left_menu_top_frame)
        self.left_menu_top_layout.setContentsMargins(0,0,0,0)
        self.left_menu_top_layout.setSpacing(0)

        #КНОПКИ СОЗДАНЫЕ ЧЕРЕЗ ВИДЖЕТ ИЗ ФАЙЛ ПАЙПУШ БАТОН
        self.toggle_button = PyPushButton(
            text = "Menu",
            icon_path = "icon_menu.svg"
        )
        self.btn_1 = PyPushButton(
            text = "Home",
            is_active = True,
            icon_path = "icon_code.svg"
        )
        self.btn_2 = PyPushButton(
            text = "Libs",
            icon_path = "icon_libs.svg"
        )
        self.btn_logo = LogoPushButton(
            text = "WhyCode",
            icon_path = "icon_whycom.png"

        )

        self.left_menu_top_layout.addWidget(self.btn_logo)
        self.left_menu_top_layout.addWidget(self.toggle_button)
        self.left_menu_top_layout.addWidget(self.btn_1)
        self.left_menu_top_layout.addWidget(self.btn_2)

        self.left_menu_spacer = QSpacerItem(20,20, QSizePolicy.Minimum, QSizePolicy.Expanding)


        self.left_menu_bottom_frame = QFrame()
        self.left_menu_bottom_frame.setMinimumHeight(40)
        self.left_menu_bottom_frame.setObjectName("left_menu_bottom_frame")

        self.left_menu_bottom_layout = QVBoxLayout(self.left_menu_bottom_frame)
        self.left_menu_bottom_layout.setContentsMargins(0,0,0,0)
        self.left_menu_bottom_layout.setSpacing(0)


        self.settings_btn = PyPushButton(
            text = "Settings",
            icon_path = "icon_settings.svg"
        )
        self.left_menu_bottom_layout.addWidget(self.settings_btn)

        self.left_menu_label_version = QLabel("Alfa")
        self.left_menu_label_version.setAlignment(Qt.AlignCenter)
        self.left_menu_label_version.setMinimumHeight(30)
        self.left_menu_label_version.setMaximumHeight(30)
        self.left_menu_label_version.setStyleSheet("color: #afb1b3")


        self.left_menu_layout.addWidget(self.left_menu_top_frame)
        self.left_menu_layout.addItem(self.left_menu_spacer)
        self.left_menu_layout.addWidget(self.left_menu_bottom_frame)
        self.left_menu_layout.addWidget(self.left_menu_label_version)


        self.content = QFrame()
        self.content.setStyleSheet("background-color: #282a36")

        self.content_layout = QGridLayout(self.content)
        self.content_layout.setContentsMargins(0,0,0,0)
        self.content_layout.setSpacing(0)

        self.pages = QStackedWidget()
        self.pages.setStyleSheet("font-size: 12pt; color: #f8f8f2;")
        self.ui_pages.setup_Ui(self.pages)
        self.pages.setCurrentWidget(self.ui_pages.page_1)

        self.bottom_bar = QFrame()
        self.bottom_bar.setMinimumHeight(30)
        self.bottom_bar.setMaximumHeight(30)
        self.bottom_bar.setStyleSheet("background-color: #323844; color: #6272a4")

        self.bottom_bar_layout = QHBoxLayout(self.bottom_bar)
        self.bottom_bar_layout.setContentsMargins(10,0,10,0)


        self.bottom_label_left = QLabel("WhyCompany Inc.")


        self.bottom_spacer = QSpacerItem(20,20, QSizePolicy.Expanding, QSizePolicy.Minimum)


        self.bottom_label_right = QLabel("WhyCode 3.1.0")
        self.bottom_label_right.setAlignment(Qt.AlignRight)
        self.bottom_bar.setStyleSheet("background-color: #22252c; color: #afb1b3")


        self.bottom_bar_layout.addWidget(self.bottom_label_left)


        self.content_layout.addWidget(self.pages, 1, 0, 1, 5)
        self.content_layout.addWidget(self.title_lable, 0, 0)
        self.content_layout.addWidget(self.btn_min, 0, 2)
        self.content_layout.addWidget(self.btn_form, 0, 3)
        self.content_layout.addWidget(self.btn_close, 0, 4)
        self.content_layout.addWidget(self.btn_donate, 0, 1)
        self.content_layout.addWidget(self.bottom_bar, 2, 0, 1, 5)


        self.main_layout.addWidget(self.left_menu, 0, 0)
        self.main_layout.addWidget(self.content, 0, 1)

        parent.setCentralWidget(self.central_frame)
