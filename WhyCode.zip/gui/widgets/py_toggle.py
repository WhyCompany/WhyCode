############КРАСИВЫЙ АНИМИРОВАННЫЙ ПЕРЕКЛЮЧАЕТЕЛЬ#################

from qt_core import *

class PyToggle(QCheckBox):
    def __init__(
        self,
        width = 60,
        bg_color = '#323844',
        circle_color = '#ffffff',
        active_color = '#1486c6',
        animation_curve = QEasingCurve.OutBounce
    ):
        QCheckBox.__init__(self)
        #PARAMETERS
        self.setFixedSize(width, 28)
        self.setCursor(Qt.PointingHandCursor)

        #COLORS
        self._bg_color = bg_color
        self._circle_color = circle_color
        self._active_color = active_color

        #ANIMATING
        self._circle_position = 3
        self.animation = QPropertyAnimation(self, b"circle_position", self)
        self.animation.setEasingCurve(animation_curve)
        self.animation.setDuration(500)

        #CONNECT CHANGES
        self.stateChanged.connect(self.start_transition)

    #PROPERTIES
    @Property(float)
    def circle_position(self):
        return self._circle_position

    @circle_position.setter
    def circle_position(self, pos):
        self._circle_position = pos
        self.update()


    def start_transition(self, value):
        self.animation.stop()
        if value:
            self.animation.setEndValue(self.width() - 26)
        else:
            self.animation.setEndValue(3)

        self.animation.start()

    def hitButton(self, pos: QPoint):
        return self.contentsRect().contains(pos)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        p.setPen(Qt.NoPen)

        #RECTANGLE
        rect = QRect(0, 0, self.width(), self.height())

        #CHECKED
        if not self.isChecked():
            # BG
            p.setBrush(QColor(self._bg_color))
            p.drawRoundedRect(0, 0, rect.width(), self.height(), self.height() / 2, self.height() / 2)

            # CIRCLE
            p.setBrush(QColor(self._circle_color))
            p.drawEllipse(self._circle_position, 3, 22, 22)
        else:
            # BG
            p.setBrush(QColor(self._active_color))
            p.drawRoundedRect(0, 0, rect.width(), self.height(), self.height() / 2, self.height() / 2)

            # CIRCLE
            p.setBrush(QColor(self._circle_color))
            p.drawEllipse(self._circle_position, 3, 22, 22)

        #END DRAW
        p.end()
